import joblib, sys
from tkinter import messagebox
import pandas as pd 


race_options = [
    "White",
    "Asian-Pac-Islander",
    "Amer-Indian-Eskimo",
    "Other",
    "Black",
]
sex_options = [
    "Female",
    "Male",
]
workclass_options = [
    "Private",
    "Self-emp-not-inc",
    "Self-emp-inc",
    "Federal-gov",
    "Local-gov",
    "State-gov",
    "Without-pay",
    "Never-worked",]

native_country_options = [
    "United-States", "Cambodia", "England", "Puerto-Rico", "Canada", "Germany",
    "Outlying-US(Guam-USVI-etc)", "India", "Japan", "Greece", "South", "China",
    "Cuba", "Iran", "Honduras", "Philippines", "Italy", "Poland", "Jamaica",
    "Vietnam", "Mexico", "Portugal", "Ireland", "France", "Dominican-Republic",
    "Laos", "Ecuador", "Taiwan", "Haiti", "Columbia", "Hungary", "Guatemala",
    "Nicaragua", "Scotland", "Thailand", "Yugoslavia", "El-Salvador",
    "Trinadad&Tobago", "Peru", "Hong", "Holand-Netherlands"
]

education_options = [
    "Bachelors",
    "Some-college",
    "11th",
    "HS-grad",
    "Prof-school",
    "Assoc-acdm",
    "Assoc-voc",
    "9th",
    "7th-8th",
    "12th",
    "Masters",
    "1st-4th",
    "10th",
    "Doctorate",
    "5th-6th",
    "Preschool",]

occupation_options = [
    "Tech-support",
    "Craft-repair",
    "Other-service",
    "Sales",
    "Exec-managerial",
    "Prof-specialty",
    "Handlers-cleaners",
    "Machine-op-inspct",
    "Adm-clerical",
    "Farming-fishing",
    "Transport-moving",
    "Priv-house-serv",
    "Protective-serv",
    "Armed-Forces"
]
relationship_options = [
    "Wife",
    "Own-child",
    "Husband",
    "Not-in-family",
    "Other-relative",
    "Unmarried",
]

marital_status_options = [
    "Married-civ-spouce",
    "Divorced",
    "Never-married",
    "Seperated",
    "Widowed",
    "Married-spouce=absent",
    "Married-AF-spouce"]

def clearer():
    age_entry.delete(0, tk.END)
    workclass_variable.set(workclass_options[0])
    wnlwgt_entry.delete(0, tk.END)
    education_variable.set(education_options[0])
    education_num_entry.delete(0, tk.END)
    marital_status_variable.set(marital_status_options[0])
    occupation_variable.set(occupation_options[0])
    relationship_variable.set(relationship_options[0])
    race_variable.set(race_options[0])
    sex_variable.set(sex_options[0])
    capital_gain_entry.delete(0, tk.END)
    capital_loss_entry.delete(0, tk.END)
    hours_per_week_entry.delete(0, tk.END)
    native_country_variable.set(native_country_options[0])
def xcit():
    sys.exit()

loaded_model = joblib.load('model.joblib')

def predictions(input_dataset):
    input_DataFrame = pd.DataFrame([input_dataset])
    prediction = loaded_model.predict(input_DataFrame)
    return prediction[0]

def subm():
    input_data = {
        'age': int(age_entry.get()),
        'workclass': workclass_variable.get(),  
        'fnlwgt': int(wnlwgt_entry.get()),
        'education': education_variable.get(),
        'education-num': int(education_num_entry.get()),
        'marital-status': marital_status_variable.get(),
        'occupation': occupation_variable.get(), 
        'relationship': relationship_variable.get(),
        'race':race_variable.get(),
        'sex': sex_variable.get(),
        'capital-gain': int(capital_gain_entry.get()),
        'capital-loss': int(capital_loss_entry.get()),
        'hours-per-week': int(hours_per_week_entry.get()),
        'native-country': native_country_variable.get()
    }
    ress = predictions(input_data)
    tk.messagebox.showinfo(title='info', message=ress)
import tkinter as tk 
win = tk.Tk()
win.title("Income Prediction")

tk.Label(win, text=f"Enter the following things to get a prediction", font=("Arial, 20")).grid(row=0, columnspan=7, sticky='nswe')
#creating thngy
tk.Label(win, text="age").grid(row=1, column=0,sticky='nsew')
age_entry = tk.Entry(win)
age_entry.grid(row=2, column=0, sticky='nswe')

tk.Label(win,text='workclass').grid(row=1, column=1,sticky='nswe')
workclass_variable = tk.StringVar(win)
workclass_variable.set(workclass_options[0])
workclassOM = tk.OptionMenu(win, workclass_variable, *workclass_options)
workclassOM.grid(row=2, column=1, sticky="NSWE")

tk.Label(win,text='fnlwgt').grid(row=1, column=2,sticky='nswe')
wnlwgt_entry = tk.Entry(win)
wnlwgt_entry.grid(row=2, column=2, sticky='nswe')

tk.Label(win, text='education').grid(row=1, column=3,sticky='nswe')
education_variable = tk.StringVar(win)
education_variable.set(education_options[0])
educationOM = tk.OptionMenu(win, education_variable, *education_options)
educationOM.grid(row=2, column=3, sticky='nswe')

tk.Label(win, text='education-num').grid(row=1, column=4,sticky='nswe')
education_num_entry = tk.Entry(win)
education_num_entry.grid(row=2, column=4, sticky='nsew')

tk.Label(win, text="marital-status").grid(row=1, column=5, sticky='nsew')
marital_status_variable = tk.StringVar(win)
marital_status_variable.set(marital_status_options[0])
marital_statusOM = tk.OptionMenu(win, marital_status_variable, *marital_status_options)
marital_statusOM.grid(row=2, column=5, sticky="nswe")


tk.Label(win, text="occupation").grid(row=1, column=6, sticky='nsew')
occupation_variable = tk.StringVar(win)
occupation_variable.set(occupation_options[0])
occupationOM = tk.OptionMenu(win, occupation_variable, *occupation_options)
occupationOM.grid(row=2, column=6, sticky="nswe")

tk.Label(win, text='relationship').grid(row=3, column=0, sticky='nswe')
relationship_variable = tk.StringVar(win)
relationship_variable.set(relationship_options[0])
relationshipOM = tk.OptionMenu(win, relationship_variable, *relationship_options)
relationshipOM.grid(row=4, column=0, sticky="NSWE")


tk.Label(win, text="race").grid(row=3, column=1, sticky='nswe')
race_variable = tk.StringVar(win)
race_variable.set(race_options[0])
raceOM = tk.OptionMenu(win, race_variable, *race_options)
raceOM.grid(row=4, column=1, sticky="NSWE")


tk.Label(win, text="sex/gender").grid(row=3, column=2, sticky='nswe')
sex_variable = tk.StringVar(win)
sex_variable.set(sex_options[0])
sexOM = tk.OptionMenu(win, sex_variable, *sex_options)
sexOM.grid(row=4, column=2, sticky="NSWE")



tk.Label(win, text="capital-gain").grid(row=3, column=3, sticky='nswe')
capital_gain_entry = tk.Entry(win)
capital_gain_entry.grid(row=4, column=3, sticky="nswe")

tk.Label(win, text="capital-loss").grid(row=3, column=4, sticky='nswe')
capital_loss_entry = tk.Entry(win)
capital_loss_entry.grid(row=4, column=4, sticky='nswe')

tk.Label(win, text="hours-per-week").grid(row=3, column=5, sticky='nswe')
hours_per_week_entry = tk.Entry(win)
hours_per_week_entry.grid(row=4,column=5, sticky="nswe")

tk.Label(win, text="native-country").grid(row=3, column=6, sticky='nswe')
native_country_variable = tk.StringVar(win)
native_country_variable.set(native_country_options[0])
native_countryOM = tk.OptionMenu(win, native_country_variable, *native_country_options)
native_countryOM.grid(row=4, column=6, sticky="nwse")




submit_btn = tk.Button(win, text='submit', font=('Arial', 15), command=subm)
submit_btn.grid(row=5, column=3, columnspan=1, sticky='nswe')
close_btn = tk.Button(win, text='X', font=('Arial', 15), command=xcit)
close_btn.grid(row=5, column=5, sticky='nsew')
clear_btn = tk.Button(win, text="clear", font=("Arial", 15), command=clearer)
clear_btn.grid(row=5, column=4, sticky='nswe')

win.mainloop()
"""
Becker, B. & Kohavi, R. (1996). Adult [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5XW20.



"""
